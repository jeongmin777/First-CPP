//#pragma once					// ��ǥ��(VS)

#ifndef __MY_FUNCTION_H__		// ǥ��
#define __MY_FUNCTION_H__

void myFunction1();
void myFunction2();

#endif